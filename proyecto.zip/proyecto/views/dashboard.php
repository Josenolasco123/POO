<div class="card mt-3"> 
  <div class="card-header d-flex justify-content-between align-items-center">
   <p><b>Bienvenido/a:</b></p>

   <form action="index.php" method="post" onsubmit="return confirm('Decea cerrrar sesión')">
        <input type="hidden" name="off" value="1">
        <button type="submit" class="btn btn-danger btn-sm">
            <i class="fa-solid fa-right-from-bracket"></i>
        </button>
   </form>
  </div>
  <div class="card-body">
    <div class="row">
        <div class="col-md-4 ">
            <div class="card mt-1 w-75 mx-auto">
                <div class="card-header text-center">
                    <b>Panel Usuarios</b>
                </div>
                <div class="card-body text-center">
                <a href="./views/usuarios/index.php" class="btn btn-primary" >
                    <i class="fa-solid fa-users fa-2x"></i>
                </a>
                </div>
            </div>
        </div>
        <div class="col-md-4 ">
            <div class="card mt-1 w-75 mx-auto">
                <div class="card-header text-center">
                    <b>Panel Empleados</b>
                </div>
                <div class="card-body  text-center">
                <a href="./views/usuarios/index.php" class="btn btn-primary" >
                    <i class="fa-solid fa-users fa-2x"></i>
                </a>
                </div>
            </div>
        </div>
        <div class="col-md-4 ">
            <div class="card mt-1 w-75 mx-auto">
                <div class="card-header text-center">
                    <b>Categoría</b>
                </div>
                <div class="card-body  text-center">
                <a href="./views/usuarios/index.php" class="btn btn-primary" >
                    <i class="fa-solid fa-users fa-2x"></i>
                </a>
                </div>
            </div>
        </div>
    </div>
  </div> 
  </div>
</div>

