
<?php
    if(isset($_REQUEST['off'])){
        session_start();
        $_SESSION = array();
        session_destroy();
        unset($_SESSION['login_ok']);
        echo '
            <script>
                window.location.replace = "index.php";
            </script>
        ';

    } else{
        session_start();
    }
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php if(isset($_SESSION['login_ok'])):?>
        <title>CRUD</title>
    <?php else:?>
        <title>Login</title>
    <?php endif ?>
    <!-- Bootstrap CSS -->
    <link rel="shortcut icon" href="./public/img/crud.png" type="image/x-icon">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" href="./public/css/alertify.css">
    <link rel="stylesheet" href="./public/css/default.css">
    <link rel="stylesheet" href="./public/css/inputmask.min.css">
    <link rel="stylesheet" href="./public/css/style.css">
    <!-- JS -->
    <script src="./public/js/jquery-3.7.1.min.js"></script>
    <script src="./public/js/bootstrap.bundle.min.js"></script>
    <script src="./public/js/alertify.js"></script>
    <script src="./public/js/inputmask.min.js"></script>
    <script src="./public/js/jquery.inputmask.bundle.js"></script>
    <script src="./public/js/fontawesome.js"></script>
</head>  
<body id="toor">
    <div id="principal" class="container-fluid">
        <?php
            if(isset($_SESSION['login_ok'])){
                require_once('views/dashboard.php');
            }else{
                require_once('views/login.php');
            }
        ?>
    </div>
</body>
</html>
