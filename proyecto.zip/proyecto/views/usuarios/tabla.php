﻿<?php
/*configurar el paginado*/
$registrosporpagina = 5; //Cantidad de registros por pagina
//obener numero de pagina
$pagina = (isset($_GET['page']))? (int) $_GET['page'] : 1; //Si existe la variable pagina, se le asigna a $pagina, si no existe se le asigna 1
//evitar que se utilize paginas menores que 1
if($pagina < 1){
    $pagina = 1;
}
//controlar todos los registros
$sqlTotal = "SELECT COUNT(*) AS total FROM usuarios AS u INNER JOIN roles AS r ON u.idrol=r.idrol"; //Contar todos los registros de la tabla usuarios
$sqlTotal = CRUD($sqlTotal,"S"); //Se ejecuta la consulta y se guarda en la variable $sqlTotal
$totalRegistros = $sqlTotal[0]['total']??0; //Se obtiene el total de registros
//calcular el total de paginas
$totalPaginas = ceil($totalRegistros / $registrosporpagina); //Se calcula el total de paginas dividiendo el total de registros entre la cantidad de registros por pagina y se red
//validar ultima pagina
if($totalPaginas > 0 && $pagina > $totalPaginas){
    $pagina = $totalPaginas;
}
//offset
$offset = ($pagina - 1) * $registrosporpagina; //Se calcula el offset multiplicando la pagina actual menos 1 por la cantidad de registros por pagina


 $sql = "SELECT *
  FROM usuarios AS u
  INNER JOIN roles AS r ON u.idrol=r.idrol order by u.idusuario asc limit $registrosporpagina offset $offset";
  
 $dataUsuarios = CRUD($sql,"s");

?>
<a href="" class="btn btn-primary btn-sm btn-usuario-blanco">
    <i class="fa-solid fa-user-plus"></i>
</a>
<hr>
<div class="table-responsive ">
    <table class="table table-borderless table-bodered table-hover table-sm" border="1" style="border-collapse: collapse;">
        <thead class="table-dark ccv p-3">
            <tr>
                <th class="ccv" >ID</th>
                <th class="ccv">Usuario</th>
                <th class="ccv">Email</th>
                <th class="ccv">Rol</th>
                <th class="ccv">Estado</th>
                <th class="ccv" colspan="3">Acciones</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($dataUsuarios AS $result): ?>

                <tr>
                    <td><?= $result['idusuario'] ?></td>
                    <td><?= $result['usuario']?></td>
                    <td><?= $result['email']?></td>
                    <td><?= $result['rol'] ?></td>
                    <td><?= ($result['estado'] == 1)? 'Activo' : 'Inactivo';?></td>
                    <td></td>
                    <td></td>
                    <td></td>
                </tr>
            <?php endforeach?>
        </tbody>
    </table>
    
</div>
<?php if($totalPaginas > 0): ?>
    <div class="d-flex justify-content-between align-items-center mt-3">
        <small class="text-muted">
            pagina <strong><?= $pagina; ?></strong> de <strong><?= $totalPaginas; ?></strong> | Total de registros:
            registros <strong><?= $totalRegistros; ?></strong>
        </small>
        <nav aria-label="Paginacion de Usuarios">
            <ul class="pagination pagination-sm mb-0 pagination-usuarios">
                <?php if($pagina > 1): ?>
                    <li class="page-item">
                        <a href="?page=<?= $pagina - 1; ?>" class="page-link">
                            Anterior <i class="fa-solid fa-angle-left"></i>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">
                            Anterior <i class="fa-solid fa-angle-left"></i>
                        </span>
                    </li>
                <?php endif; ?>

                <?php for($i = 1; $i <= $totalPaginas; $i++): ?>
                    <?php if($i == $pagina): ?>
                        <li class="page-item active">
                            <span class="page-link"><?= $i; ?></span>
                        </li>
                    <?php else: ?>
                        <li class="page-item">
                            <a href="?page=<?= $i; ?>" class="page-link"><?= $i; ?></a>
                        </li>
                    <?php endif; ?>
                <?php endfor; ?>

                <!boton siguiente>

                <?php if($pagina < $totalPaginas): ?>
                    <li class="page-item">
                        <a href="?page=<?= $pagina + 1; ?>" class="page-link">
                            Siguiente <i class="fa-solid fa-angle-right"></i>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="page-item disabled">
                        <span class="page-link">
                            Siguiente <i class="fa-solid fa-angle-right"></i>
                        </span>
                    </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
<?php endif; ?>
